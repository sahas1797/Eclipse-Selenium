package MyPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FluentWait {

	public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\sahas\\Desktop\\Sahas\\WebDriver\\chromedriver.exe");
		
		WebDriver wb= new ChromeDriver();
		wb.get("https://www.facebook.com/");
		
		wb.findElement(By.xpath("//*[@id='pageFooter']/div[3]/div/span")).click();

	}

}
