package MyPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Fresh {

	public static void main(String[] args) {
		
		int [] arr= {1,2,3,4,5};
		
		for(int i:arr)
			System.out.println(i);
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\sahas\\Desktop\\Sahas\\WebDriver\\chromedriver.exe");
		
		WebDriver wb= new ChromeDriver();
		
		wb.get("https://www.javatpoint.com/selenium-webdriver-first-test-case");
	

	}

}
