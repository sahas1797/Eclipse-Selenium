package MyPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class Iframes {
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\sahas\\Desktop\\Sahas\\WebDriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demoqa.com/frames");
		
		
		//(Getting total number of Iframes in a webPage)
		List<WebElement> iframeElements = driver.findElements(By.tagName("iframe"));
		System.out.println("The total number of iframes are " + iframeElements.size());
		
		WebElement c=driver.findElement(By.cssSelector("iframe[id='frame2']"));
		
		driver.switchTo().frame(c);
		
		System.out.println(driver.getPageSource());
		
		driver.switchTo().defaultContent();
		
		driver.findElement(By.className("header-text")).click();
		
	}

}
