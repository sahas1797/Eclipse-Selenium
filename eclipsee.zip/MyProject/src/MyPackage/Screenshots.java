package MyPackage;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.HasFullPageScreenshot;

public class Screenshots {

	

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\sahas\\Desktop\\Sahas\\WebDriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.toolsqa.com/selenium-webdriver/screenshot-in-selenium/");
		
		//Taking the Screenshot
		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		
		//Storing the screenshot at a particular location in PC
		FileUtils.copyFile(screenshot, new File("C:\\Users\\sahas\\Desktop\\Sahas\\Selenium Screenshot\screenshot.png"));
		
		driver.close();

	}

}
